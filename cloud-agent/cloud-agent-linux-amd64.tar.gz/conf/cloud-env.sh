# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License

# To change a passphrase used by the agent adjust the line below. This value is used when no passphrase is
# given through environment variable

cloud_PASSPHRASE="DEV"
export PATH=$PATH:/usr/local/cloud-agent
export PYTHONPATH=/usr/local/cloud-agent/lib:$PYTHONPATH

# customize python binary for cloud
# export PYTHON=/usr/bin/python2
