#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import unittest
from mock.mock import patch, MagicMock, call, Mock  # 导入模拟测试工具
from cloud_agent import DataCleaner  # 导入数据清理模块
from cloud_agent import cloudConfig  # 导入配置模块
import os  # 导入文件系统操作模块
from cloud_commons import OSCheck  # 导入操作系统检测模�?from only_for_platform import os_distro_value  # 导入平台相关�?

class TestDataCleaner(unittest.TestCase):
    """单元测试类：验证数据清理功能的正确�?""
    
    def setUp(self):
        """准备测试环境：创建模拟文件结构和配置"""
        # 创建模拟的测试目录结�?        self.test_dir = [
            (
                "test_path",  # 目录路径
                [],  # 子目录列�?                [  # 文件列表
                    "errors-12.txt",      # 错误日志文件
                    "output-12.txt",      # 输出文件
                    "site-12.pp",         # Puppet配置文件
                    "site-13.pp",         # Puppet配置文件
                    "site-15.pp",         # Puppet配置文件
                    "structured-out-13.json",  # 结构化输�?                    "command-13.json",    # 命令配置文件
                    "version",             # 版本文件（非清理目标�?                ],
            )
        ]
        
        # 创建模拟配置对象
        self.config = MagicMock()
        # 配置返回参数：最长存活时�?�?、清理间�?�?、最大容�?MB)、路�?        self.config.get.side_effect = [2592000, (3600 + 1), 10000, "test_path"]
        
        # 重置模拟日志对象
        DataCleaner.logger = MagicMock()

    def test_init_success(self):
        """测试配置有效�?- 验证正常配置参数处理"""
        # 初始化模拟配�?        config = MagicMock()
        config.get.side_effect = [2592000, (3600 + 1), 10000, "test_path"]
        DataCleaner.logger.reset_mock()
        
        # 创建数据清理器实�?        cleaner = DataCleaner.DataCleaner(config)
        
        # 验证初始化无警告
        self.assertFalse(DataCleaner.logger.warn.called)

    @patch.object(OSCheck, "os_distribution", new=MagicMock(return_value=os_distro_value))
    def test_config(self):
        """测试默认配置 - 验证缺失配置参数时的默认值设�?""
        # 重置日志
        DataCleaner.logger.reset_mock()
        
        # 创建实际配置对象并移除特定配置项
        config = cloudConfig.cloudConfig()
        config.remove_option("agent", "data_cleanup_max_age")
        config.remove_option("agent", "data_cleanup_interval")
        config.remove_option("agent", "data_cleanup_max_size_MB")
        
        # 创建数据清理器实�?        cleaner = DataCleaner.DataCleaner(config)
        
        # 验证默认值配�?        self.assertEqual(cleaner.file_max_age, 86400)  # 默认最大文件年�?1�?
        self.assertEqual(cleaner.cleanup_interval, 3600)  # 默认清理间隔(1小时)
        self.assertEqual(cleaner.cleanup_max_size_MB, 10000)  # 默认最大容�?10GB)

    def test_init_warn(self):
        """测试配置警告 - 验证异常参数检测和默认值修�?""
        # 配置异常参数�?        config = MagicMock()
        # 文件最大年龄过�?1�?、清理间隔过�?3600-1�?、清理容量过�?10000+1MB)
        config.get.side_effect = [1, (3600 - 1), (10000 + 1), "test_path"]
        DataCleaner.logger.reset_mock()
        
        # 创建数据清理器实�?        cleaner = DataCleaner.DataCleaner(config)
        
        # 验证警告日志被调�?        self.assertTrue(DataCleaner.logger.warn.called)
        # 验证异常参数被修正为默认�?        self.assertEqual(cleaner.file_max_age, 86400)
        self.assertEqual(cleaner.cleanup_interval, 3600)
        self.assertEqual(cleaner.cleanup_max_size_MB, 10000)

    @patch("os.walk")           # 模拟文件系统遍历
    @patch("time.time")         # 模拟时间获取
    @patch("os.path.getmtime")  # 模拟文件修改时间获取
    @patch("os.remove")         # 模拟文件删除
    @patch("os.path.getsize")   # 模拟文件大小获取
    def test_cleanup_success(self, sizeMock, remMock, mtimeMock, timeMock, walkMock):
        """测试成功清理 - 验证清理逻辑正确删除目标文件"""
        # 重置配置和日�?        self.config.reset_mock()
        DataCleaner.logger.reset_mock()
        
        # 配置模拟行为
        walkMock.return_value = iter(self.test_dir)  # 返回预定义测试目�?        timeMock.return_value = 2592000 + 2  # 当前时间(30�?2�?
        # 文件修改时间模拟：version文件�?秒前，其他都�?秒前
        mtimeMock.side_effect = [1, 1, 1, 2, 1, 1, 1, 1]
        sizeMock.return_value = 100  # 每个文件100字节
        
        # 创建清理器并执行清理
        cleaner = DataCleaner.DataCleaner(self.config)
        cleaner.cleanup()
        
        # 验证文件删除操作调用次数�?个文件应被删除）
        self.assertEqual(len(remMock.call_args_list), 6)
        # 验证应删除的文件列表
        remMock.assert_any_call(os.path.join("test_path", "errors-12.txt"))
        remMock.assert_any_call(os.path.join("test_path", "output-12.txt"))
        remMock.assert_any_call(os.path.join("test_path", "site-12.pp"))
        remMock.assert_any_call(os.path.join("test_path", "site-15.pp"))
        remMock.assert_any_call(os.path.join("test_path", "structured-out-13.json"))
        remMock.assert_any_call(os.path.join("test_path", "command-13.json"))

    @patch("os.walk")
    @patch("time.time")
    @patch("os.path.getmtime")
    @patch("os.remove")
    @patch("os.path.getsize")
    def test_cleanup_remove_error(self, sizeMock, remMock, mtimeMock, timeMock, walkMock):
        """测试清理异常 - 验证文件删除失败时的错误处理能力"""
        # 重置配置和日�?        self.config.reset_mock()
        DataCleaner.logger.reset_mock()
        
        # 配置模拟行为
        walkMock.return_value = iter(self.test_dir)
        timeMock.return_value = 2592000 + 2
        mtimeMock.side_effect = [1, 1, 1, 2, 1, 1, 1, 1]
        sizeMock.return_value = 100
        
        # 创建特定文件的删除异�?        def side_effect(arg):
            """模拟site-15.pp文件的删除异�?""
            if arg == os.path.join("test_path", "site-15.pp"):
                raise Exception("Can't remove file")
                
        remMock.side_effect = side_effect
        
        # 创建清理器并执行清理
        cleaner = DataCleaner.DataCleaner(self.config)
        cleaner.cleanup()
        
        # 验证文件删除尝试次数
        self.assertEqual(len(remMock.call_args_list), 6)
        # 验证错误日志记录次数
        self.assertEqual(DataCleaner.logger.error.call_count, 1)
