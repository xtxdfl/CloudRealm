#!/usr/bin/env python3

"""
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

# 导入网络工具模块
from cloud_agent import NetUtil

# 导入测试框架和模拟库
from mock.mock import MagicMock, patch
import unittest

# 导入线程和平台检测模�?import threading
from cloud_commons import OSCheck

# 导入平台相关工具和常�?from only_for_platform import not_for_platform, os_distro_value, PLATFORM_WINDOWS


class TestNetUtil(unittest.TestCase):
    """单元测试类：验证NetUtil网络功能模块"""

    # 定义代理方法：测试URL校验功能
    @patch.object(OSCheck, "os_distribution", new=MagicMock(return_value=os_distro_value))
    @patch("urlparse.urlparse")    # 模拟URL解析
    @patch("httplib.HTTPSConnection")  # 模拟HTTPS连接
    def test_checkURL(self, httpsConMock, parseMock):
        """测试URL检查功�?- 验证网络连接状态检测能�?""
        
        # 设置模拟日志记录�?        NetUtil.logger = MagicMock()
        
        # 配置URL解析模拟行为
        parseMock.return_value = [1, 2]  # 模拟URL解析结果
        
        # 创建模拟HTTPS连接对象
        ca_connection = MagicMock()
        response = MagicMock()
        response.status = 200
        ca_connection.getresponse.return_value = response
        httpsConMock.return_value = ca_connection

        # 实例化网络工具对�?        netutil = NetUtil.NetUtil(MagicMock())

        ### 测试200状态码场景 ###
        success, _ = netutil.checkURL("url")
        self.assertTrue(success)  # 验证成功状态检�?
        ### 测试404失败场景 ###
        response.status = 404  # 配置返回404状�?        success, _ = netutil.checkURL("url")
        self.assertFalse(success)  # 验证失败状态检�?
        ### 测试连接异常场景 ###
        response.status = 200
        httpsConMock.side_effect = Exception("test")  # 模拟连接异常
        success, _ = netutil.checkURL("url")
        self.assertFalse(success)  # 验证异常处理能力

    # 非Windows平台测试：验证连接重试逻辑
    @not_for_platform(PLATFORM_WINDOWS)  # 跳过Windows平台
    @patch("time.sleep")            # 模拟睡眠功能避免测试延迟
    @patch.object(threading.Event, "wait")  # 模拟事件等待
    def test_try_to_connect(self, event_mock, sleepMock):
        """测试连接重试机制 - 验证网络异常恢复能力"""
        
        # 配置事件等待模拟行为
        event_mock.return_value = False  # 永不超时
        
        # 实例化网络工具对�?        netutil = NetUtil.NetUtil(MagicMock())
        
        # 替换URL检查方法为模拟行为
        checkURL = MagicMock(name="checkURL")
        netutil.checkURL = checkURL

        ### 测试首次连接成功场景 ###
        checkURL.return_value = True, "test"
        retries, success, time_exceeded = netutil.try_to_connect("url", 10)
        # 验证状态：0次重试，成功，未超时
        self.assertEqual((0, True, False), (retries, success, time_exceeded))

        ### 测试失败后重试成功场�?###
        # 模拟三次连接结果（从后往前弹出）
        gets = [[True, ""], [False, ""], [False, ""]]
        
        def side_effect(*args):
            """弹出函数 - 模拟变化的重试结�?""
            return gets.pop()
            
        checkURL.side_effect = side_effect
        retries, success, time_exceeded = netutil.try_to_connect("url", 10)
        # 验证状态：2次重试，成功，未超时
        self.assertEqual((2, True, False), (retries, success, time_exceeded))

        ### 测试达到最大重试次数场�?###
        checkURL.side_effect = None
        checkURL.return_value = False, "test"
        retries, success, time_exceeded = netutil.try_to_connect("url", 5)
        # 验证状态：5次重试，失败，未超时
        self.assertEqual((5, False, False), (retries, success, time_exceeded))

    def test_get_agent_heartbeat_idle_interval_sec(self):
        """测试心跳间隔计算 - 验证核心算法功能"""
        # 实例化网络工具对�?        netutil = NetUtil.NetUtil(MagicMock())
        
        # 调用心跳间隔计算算法
        heartbeat_interval = netutil.get_agent_heartbeat_idle_interval_sec(1, 10, 32)
        
        # 验证结果：参考内部公�?log(32)/log(10)*10 �?15（但测试�?需检查算法逻辑�?        self.assertEqual(heartbeat_interval, 3)

    def test_get_agent_heartbeat_idle_interval_sec_max(self):
        """测试最大心跳间隔保�?- 验证上限约束功能"""
        netutil = NetUtil.NetUtil(MagicMock())
        
        # 调用心跳间隔算法（极大网络延迟）
        heartbeat_interval = netutil.get_agent_heartbeat_idle_interval_sec(1, 10, 1500)
        
        # 验证结果不超过预设最大�?        self.assertEqual(
            heartbeat_interval, netutil.HEARTBEAT_IDLE_INTERVAL_DEFAULT_MAX_SEC
        )

    def test_get_agent_heartbeat_idle_interval_sec_min(self):
        """测试最小心跳间隔保�?- 验证下限约束功能"""
        netutil = NetUtil.NetUtil(MagicMock())
        
        # 调用心跳间隔算法（极小网络延迟）
        heartbeat_interval = netutil.get_agent_heartbeat_idle_interval_sec(1, 10, 5)
        
        # 验证结果不低于预设最小�?        self.assertEqual(heartbeat_interval, 1)
