#!/usr/bin/env python3
# -*- coding: utf-8 -*-
version_info = (2, 1, 2)
version = ".".join(str(n) for n in version_info[:3])
release = ".".join(str(n) for n in version_info)
