#!/usr/bin/env python3
"""
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import functools
import sys
import logging
from typing import Callable, Type, Dict, Union, Any, Optional
from cloud_commons import OSCheck

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("OSFamily")

# 操作系统家族常量
OS_WINDOWS = "windows"
OS_LINUX = "linux"
OS_MAC = "mac"
OS_UNIX = "unix"
OS_ALL = "default"

class OSFamilyRegistry:
    """操作系统相关实现注册�?""
    def __init__(self):
        # 类实现注册表: {base_class: {os_family: implementation_class}}
        self.class_registry = {}
        # 函数实现注册�? {func_name: {os_family: implementation_func}}
        self.func_registry = {}
        
    def register_class(self, base_class: Type, os_family: str, implementation: Type):
        """注册类实�?""
        if base_class not in self.class_registry:
            self.class_registry[base_class] = {}
            
        self.class_registry[base_class][os_family] = implementation
        
    def register_function(self, func_name: str, os_family: str, implementation: Callable):
        """注册函数实现"""
        if func_name not in self.func_registry:
            self.func_registry[func_name] = {}
            
        self.func_registry[func_name][os_family] = implementation
    
    def get_class_implementation(self, base_class: Type, os_family: str) -> Optional[Type]:
        """获取类的特定实现"""
        if base_class not in self.class_registry:
            return None
            
        # 获取最具体的实�?        current_family = os_family
        while current_family:
            if current_family in self.class_registry[base_class]:
                return self.class_registry[base_class][current_family]
            
            # 检查父家族
            if hasattr(OSCheck, 'get_os_family_parent'):
                current_family = OSCheck.get_os_family_parent(current_family)
            else:
                break
                
        # 尝试通用实现
        for family in [OS_ALL, "any", "default"]:
            if family in self.class_registry[base_class]:
                return self.class_registry[base_class][family]
                
        # 返回基础类作为后�?        return base_class
    
    def get_function_implementation(self, func_name: str, os_family: str) -> Optional[Callable]:
        """获取函数的特定实�?""
        if func_name not in self.func_registry:
            return None
            
        # 获取最具体的实�?        current_family = os_family
        while current_family:
            if current_family in self.func_registry[func_name]:
                return self.func_registry[func_name][current_family]
            
            # 检查父家族
            if hasattr(OSCheck, 'get_os_family_parent'):
                current_family = OSCheck.get_os_family_parent(current_family)
            else:
                break
                
        # 尝试通用实现
        for family in [OS_ALL, "any", "default"]:
            if family in self.func_registry[func_name]:
                return self.func_registry[func_name][family]
                
        return None

# 全局注册表实�?registry = OSFamilyRegistry()

def os_specific_class(os_families: Union[str, list] = OS_ALL):
    """
    类装饰器：为不同操作系统族注册特定实�?    支持多个操作系统�? @os_specific_class(["windows", "linux"])
    """
    if isinstance(os_families, str):
        os_families = [os_families]
        
    def decorator(cls):
        """实际装饰器函�?""
        # 查找基类（排除object基类�?        base_classes = [bc for bc in cls.__bases__ if bc is not object]
        if not base_classes:
            logger.error(f"Class {cls.__name__} must inherit from a non-object base class for OS family implementation.")
            return cls
            
        base_class = base_classes[0]
        
        # 注册所有指定的操作系统�?        for family in os_families:
            registry.register_class(base_class, family, cls)
        
        # 设置类的__new__方法以处理实例创�?        old_new = base_class.__new__
        
        def new_with_os(cls, *args, **kwargs):
            """为当前操作系统选择正确的实现类"""
            # 获取当前操作系统�?            current_os_family = OSCheck.get_os_family().lower()
            
            # 找到合适的实现
            impl_class = registry.get_class_implementation(base_class, current_os_family)
            if not impl_class:
                impl_class = cls
                
            # 为选定类创建实�?            instance = object.__new__(impl_class)
            return instance
            
        # 只在基类尚未重写__new__时应�?        if old_new is object.__new__:
            base_class.__new__ = new_with_os
            
        return cls
        
    return decorator

def os_specific_function(os_families: Union[str, list] = OS_ALL):
    """
    函数装饰器：为不同操作系统族注册特定实现
    支持多个操作系统�? @os_specific_function(["windows", "linux"])
    """
    if isinstance(os_families, str):
        os_families = [os_families]
        
    def decorator(func):
        """实际装饰器函�?""
        func_name = f"{func.__module__}.{func.__name__}"
        
        # 注册所有指定的操作系统�?        for family in os_families:
            registry.register_function(func_name, family, func)
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            """动态分发到特定操作系统实现"""
            # 获取当前操作系统�?            current_os_family = OSCheck.get_os_family().lower()
            
            # 找到合适的实现
            impl_func = registry.get_function_implementation(func_name, current_os_family)
            
            if impl_func:
                return impl_func(*args, **kwargs)
            else:
                logger.warning(f"No implementation found for function {func_name} on OS: {current_os_family}")
                return func(*args, **kwargs)
                
        return wrapper
        
    return decorator

def register_os_fallback(cls):
    """注册默认/后备实现 (通常用于基本功能)"""
    if not registry.class_registry:
        registry.class_registry = {}
    
    # 确保类有基类（排除object�?    base_classes = [bc for bc in cls.__bases__ if bc is not object]
    if not base_classes:
        logger.error(f"Class {cls.__name__} must inherit from a non-object base class for OS fallback registration.")
        return cls
        
    base_class = base_classes[0]
    registry.register_class(base_class, OS_ALL, cls)
    return cls

# ======== 使用示例 ======== #

if __name__ == "__main__":
    # 模拟操作系统检�?    class MockOSCheck:
        @staticmethod
        def get_os_family():
            return "redhat"
    
        @staticmethod
        def get_os_family_parent(family):
            if family == "redhat":
                return "linux"
            return None
    
    # 临时覆盖OSCheck
    OSCheck = MockOSCheck
    
    # 1. 类实现示�?    class FileSystemBase:
        def read_file(self, path):
            raise NotImplementedError("Base method not implemented")
            
    @os_specific_class(OS_LINUX)
    class LinuxFileSystem(FileSystemBase):
        def read_file(self, path):
            return f"Linux reading file: {path}"
            
    @os_specific_class(OS_WINDOWS)
    class WindowsFileSystem(FileSystemBase):
        def read_file(self, path):
            return f"Windows reading file: {path}"
            
    @register_os_fallback
    class DefaultFileSystem(FileSystemBase):
        def read_file(self, path):
            return f"Default reading file: {path}"
            
    # 创建实例（根据OS动态选择�?    fs = FileSystemBase()
    print(fs.read_file("/etc/hosts"))  # 输出: Linux reading file: /etc/hosts
    
    # 2. 函数实现示例
    @os_specific_function(OS_LINUX)
    def get_system_info():
        return "Linux System Info"
        
    @os_specific_function(OS_WINDOWS)
    def get_system_info():
        return "Windows System Info"
        
    @os_specific_function(OS_ALL)
    def get_system_info():
        return "Generic System Info"
        
    # 调用函数（动态分发）
    print(get_system_info())  # 输出: Linux System Info
