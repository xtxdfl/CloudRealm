#!/usr/bin/env python3
"""
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

from . import ManagerFactory
from resource_management.libraries.functions.version import compare_versions
from resource_management.core.logger import Logger
from resource_management.core.exceptions import Fail
from cloud_commons import OSCheck

# 定义不同操作系统下的包名映射
PACKAGE_NAME_MAPPING = {
    'ubuntu': "cloud-metrics-assembly",
    'debian': "cloud-metrics-assembly",
    'default': "cloud-metrics-hadoop-sink"
}

def check_installed_metrics_hadoop_sink_version(
    checked_version: str = "2.7.0.0",
    less_valid: bool = True,
    equal_valid: bool = False,
    custom_package_name: str = None
) -> bool:
    """
    检查已安装的度量存储包是否兼容所需版本
    
    :param checked_version: 目标检查版�?    :param less_valid: 是否接受小于目标版本
    :param equal_valid: 是否接受等于目标版本
    :param custom_package_name: 自定义包名（覆盖默认映射�?    :return: 是否兼容版本要求
    
    :raises Fail: 当版本不兼容且需要强制验证时
    """
    # 1. 自动处理平台特定包名
    if custom_package_name:
        package_name = custom_package_name
    else:
        os_family = OSCheck.get_os_family()
        package_name = PACKAGE_NAME_MAPPING.get(os_family.lower(), PACKAGE_NAME_MAPPING['default'])
    
    # 2. 获取已安装包版本
    pkg_provider = ManagerFactory.get()
    installed_version = pkg_provider.get_installed_package_version(package_name)
    
    # 3. 处理未安装的情况
    if not installed_version:
        Logger.warning(
            f"无法确定 [{package_name}] 的版本，跳过兼容性检�?
        )
        return False
    
    # 4. 清理版本字符串（处理发行号）
    cleaned_version = _clean_version_string(installed_version)
    
    # 5. 比较版本
    compare_result = compare_versions(cleaned_version, checked_version)
    
    # 6. 确定兼容�?    compatible = _is_version_compatible(compare_result, less_valid, equal_valid)
    
    # 7. 处理不兼容情�?    if not compatible:
        compatibility_type = _get_compatibility_type(less_valid, equal_valid)
        
        err_msg = (
            f"度量存储�?[{package_name}] 版本不兼�?- "
            f"已安�? {installed_version} ({cleaned_version}), "
            f"要求: {compatibility_type}{checked_version}\n"
            f"建议: {_get_resolution_suggestion(less_valid, equal_valid)}"
        )
        
        if not _should_skip_check(cleaned_version, checked_version, less_valid, equal_valid):
            Logger.error(err_msg)
            raise Fail(err_msg)
        else:
            Logger.warning(f"{err_msg} - 由于特定条件跳过强制检�?)
            return False
    
    # 8. 记录成功结果
    Logger.info(
        f"度量存储包兼容性检查通过: {package_name} {installed_version} "
        f"满足 {_get_compatibility_type(less_valid, equal_valid)}{checked_version}"
    )
    return True

# ======================== 内部辅助函数 ========================

def _clean_version_string(version: str) -> str:
    """清理版本字符串以进行比较"""
    # 优先尝试保留完整版本信息
    cleaned = version
    
    # 移除发行号部分（如果存在）如: "1.2.3-4" �?"1.2.3
    if any(char in version for char in ('-', ':')):
        # 处理 "1.2.3-4" �?"1:2.3.4" 等格�?        version_parts = []
        
        for part in version.replace('-', '.').replace(':', '.').split('.'):
            if part.isdigit():
                version_parts.append(part)
            else:
                # 遇到非数字部分停�?                break
        
        return '.'.join(version_parts) if version_parts else version.split('-')[0]
    return version

def _is_version_compatible(compare_result: int, less_valid: bool, equal_valid: bool) -> bool:
    """确定版本是否兼容要求"""
    if less_valid and equal_valid:
        # 要求 <= checked_version
        return compare_result in (-1, 0)
    elif less_valid and not equal_valid:
        # 要求 < checked_version
        return compare_result == -1
    elif not less_valid and equal_valid:
        # 要求 >= checked_version
        return compare_result in (0, 1)
    else:
        # 要求 > checked_version
        return compare_result == 1

def _get_compatibility_type(less_valid: bool, equal_valid: bool) -> str:
    """获取兼容性类型的描述文本"""
    if less_valid and equal_valid:
        return "<= "
    elif less_valid and not equal_valid:
        return "< "
    elif not less_valid and equal_valid:
        return ">= "
    else:
        return "> "

def _get_resolution_suggestion(less_valid: bool, equal_valid: bool) -> str:
    """获取版本冲突的解决建�?""
    if less_valid:
        return (
            "使用更旧版本或更新软件栈以兼容此版本的度量存储包 "
            "(可通过升级堆栈或降级包解决)"
        )
    else:
        return (
            "使用更新版本或降级软件栈以兼容此版本的度量存储包 "
            "(可通过降级堆栈或升级包解决)"
        )

def _should_skip_check(
    cleaned_version: str, 
    checked_version: str,
    less_valid: bool,
    equal_valid: bool
) -> bool:
    """
    在特定条件下跳过严格检�?    
    在某些特殊情况下，即使版本不匹配，我们可能也不希望中断流�?    """
    # 1. 开发环境跳�?    if cleaned_version.startswith('dev'):
        Logger.info("开发版本检测到，跳过严格兼容性检�?)
        return True
    
    # 2. 当检查版本非常旧时跳�?    if compare_versions(checked_version, "1.0.0") == -1:
        Logger.info("检测到非常旧的检查版本，跳过严格兼容性检�?)
        return True
    
    # 3. 使用安全版本范围
    if less_valid and equal_valid and cleaned_version.count('.') < 3:
        Logger.info("简化的版本格式可能影响兼容性判断，跳过严格检�?)
        return True
    
    return False

