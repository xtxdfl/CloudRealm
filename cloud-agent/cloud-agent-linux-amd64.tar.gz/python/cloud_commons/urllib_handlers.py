#!/usr/bin/env python3

"""
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import logging
import re
from typing import Optional, Tuple, Dict, Union
from collections import namedtuple
from urllib.parse import urlparse, urlunparse, urljoin
from urllib.request import BaseHandler, Request
import html
import http.client
from datetime import timedelta
import time

logger = logging.getLogger(__name__)

# 配置日志格式
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[logging.StreamHandler()]
)

REFRESH_HEADER = "refresh"
META_REFRESH_RE = re.compile(
    r'(?:<\s*meta[^>]+http-equiv\s*=\s*("|\')?refresh\1?[^>]*content\s*=\s*("|\')?\s*(\d+\s*;\s*(?:url\s*=)?\s*([^\'\">]+))\s*\2?',
    re.IGNORECASE
)

RefreshInfo = namedtuple('RefreshInfo', ['url', 'delay', 'redirect_type'])

class RedirectSecurityError(Exception):
    """重定向安全异�?""
    pass

class RefreshHeaderProcessor(BaseHandler):
    """
    增强的HTTP刷新处理器，支持�?      - HTTP Refresh�?      - HTML Meta Refresh标签
      - 安全重定向验�?      - 跨协议重定向防护
      - 自动处理多次重定�?    """

    MAX_REDIRECTS = 5
    FORBIDDEN_SCHEMES = ('file', 'data', 'javascript', 'ftp')
    SAFE_PORTS = {80, 443, 8080, 8443}
    USER_AGENT = "cloudSecurityBot/1.0"

    def __init__(self, max_redirects: int = MAX_REDIRECTS, timeout: int = 10,
                 follow_html_refresh: bool = True):
        """
        初始化刷新处理器
        
        参数:
            max_redirects: 最大重定向次数
            timeout: 请求超时时间(�?
            follow_html_refresh: 是否跟踪HTML meta刷新
        """
        self.max_redirects = max_redirects
        self.timeout = timeout
        self.follow_html_refresh = follow_html_refresh
        self._redirect_count = 0
        self._visited_urls = set()

    def http_request(self, request: Request) -> Request:
        """准备HTTP请求（添加安全头�?""
        if not request.has_header('User-Agent'):
            request.add_header('User-Agent', self.USER_AGENT)
        if not request.has_header('Accept'):
            request.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
        return request

    def http_response(self, request: Request, response: http.client.HTTPResponse) -> http.client.HTTPResponse:
        """
        处理HTTP响应，检测并处理刷新重定�?        
        参数:
            request: 原始请求对象
            response: HTTP响应对象
            
        返回:
            原始响应或重定向后的新响�?        """
        self._redirect_count = 0
        self._visited_urls.clear()
        return self._handle_redirect(request, response)

    def _handle_redirect(self, request: Request, response: http.client.HTTPResponse,
                         content: Optional[bytes] = None) -> http.client.HTTPResponse:
        """
        递归处理重定�?        
        参数:
            request: 原始请求对象
            response: HTTP响应对象
            content: 可选的响应内容（用于HTML meta刷新�?            
        返回:
            最终响应对�?        """
        # 检查重定向限制
        if self._redirect_count >= self.max_redirects:
            logger.warning(f"达到最大重定向次数: {self.max_redirects}")
            return response
        
        # 获取刷新信息（HTTP头或HTML meta标签�?        refresh_info = self._detect_refresh(request, response, content)
        if not refresh_info:
            return response
        
        original_url = request.get_full_url()
        
        try:
            # 解析并验证重定向URL
            redirect_url = self._resolve_and_validate_redirect(original_url, refresh_info.url)
            
            # 记录重定向信�?            logger.info(f"发现{refresh_info.redirect_type}重定�?#{self._redirect_count + 1}:")
            logger.info(f"  原始URL: {original_url}")
            logger.info(f"  目标URL: {redirect_url}")
            logger.info(f"  延迟: {refresh_info.delay or 0}�?)
            
            # 检查循环重定向
            if redirect_url in self._visited_urls:
                logger.error(f"检测到重定向循�? {redirect_url}")
                return response
            self._visited_urls.add(redirect_url)
            
            # 应用延迟（如果有�?            if refresh_info.delay and refresh_info.delay > 0:
                logger.info(f"等待 {refresh_info.delay} 秒后重定�?..")
                time.sleep(refresh_info.delay)
            
            # 准备重定向请�?            redirect_req = self._prepare_redirect_request(request, redirect_url)
            
            # 增加重定向计�?            self._redirect_count += 1
            
            # 执行重定向请�?            return self.parent.open(redirect_req)
        
        except RedirectSecurityError as se:
            logger.error(f"安全重定向失�? {str(se)}")
        except Exception as e:
            logger.error(f"处理重定向时出错: {type(e).__name__} - {str(e)}")
        
        return response

    def _detect_refresh(self, request: Request, response: http.client.HTTPResponse,
                        content: Optional[bytes]) -> Optional[RefreshInfo]:
        """
        检测响应中的刷新信�?        
        支持:
          - 标准的HTTP Refresh�?          - HTML Meta刷新标签
        
        参数:
            request: HTTP请求
            response: HTTP响应
            content: 响应内容
            
        返回:
            刷新信息对象或None
        """
        # 只处�?00 OK状�?        if response.getcode() != http.HTTPStatus.OK:
            return None
        
        # 检查HTTP Refresh�?        if REFRESH_HEADER in response.headers:
            refresh_header = response.headers[REFRESH_HEADER]
            logger.debug(f"检测到Refresh�? {refresh_header}")
            return self._parse_refresh_header(refresh_header, "HTTP")
        
        # 检查HTML meta刷新标签
        if self.follow_html_refresh and (not request.get_header('Accept') or 
                                        'text/html' in request.get_header('Accept')):
            try:
                # 获取响应内容
                if content is None:
                    content = response.read()
                
                # 解码为HTML文本
                html_content = content.decode('utf-8', errors='replace')
                return self._parse_html_refresh(html_content, response.url)
            except Exception as e:
                logger.debug(f"解析HTML时出�? {str(e)}")
        
        return None

    def _parse_refresh_header(self, header_value: str, source: str) -> Optional[RefreshInfo]:
        """
        解析HTTP Refresh头�?        
        支持格式:
          "5; url=https://example.com"
          "url=https://example.com"
          "5; https://example.com"
          "https://example.com"
        
        参数:
            header_value: Refresh头�?            source: 来源标识
            
        返回:
            刷新信息对象或None
        """
        try:
            # 标准格式: [delay=] seconds ; [url=] [url]
            header_value = header_value.lower().strip()
            
            # 分割延迟和URL部分
            parts = [p.strip() for p in header_value.split(';') if p.strip()]
            
            delay = None
            url = None
            
            # 解析延迟和URL
            for part in parts:
                if 'url=' in part:
                    _, url = part.split('url=', 1)
                    url = url.strip()
                elif part.isdigit():
                    delay = int(part)
                elif self._is_url(part):
                    url = part
            
            if not url:
                return None
            
            return RefreshInfo(url=url, delay=delay, redirect_type=f"{source} header")
        except Exception:
            logger.warning(f"格式错误：无法解析Refresh头�?'{header_value}'")
            return None

    def _parse_html_refresh(self, html_content: str, base_url: str) -> Optional[RefreshInfo]:
        """
        解析HTML内容中的meta刷新标签
        
        <meta http-equiv="refresh" content="5; url=https://example.com">
        
        参数:
            html_content: HTML内容
            base_url: 基础URL（用于相对路径）
            
        返回:
            刷新信息对象或None
        """
        try:
            # 查找所有匹配的meta刷新标签
            for match in META_REFRESH_RE.finditer(html_content):
                delay_part, url_part = match.group(3), match.group(4)
                
                if not url_part:
                    continue
                
                try:
                    # 解析延迟部分
                    delay = None
                    if ';' in delay_part:
                        delay_str, _ = delay_part.split(';', 1)
                        delay = int(delay_str.strip()) if delay_str.strip().isdigit() else None
                    else:
                        if delay_part.strip().isdigit():
                            delay = int(delay_part.strip())
                
                    # 清理并解码URL
                    url = html.unescape(url_part.strip("\"' \t\r\n"))
                    
                    # 解析为相对URL的完整路�?                    full_url = urljoin(base_url, url)
                    
                    return RefreshInfo(url=full_url, delay=delay, redirect_type="HTML meta")
                except Exception as e:
                    logger.debug(f"解析HTML刷新失败: {str(e)}")
        
        except Exception as e:
            logger.debug(f"扫描HTML刷新时出�? {str(e)}")
        
        return None

    def _resolve_and_validate_redirect(self, original_url: str, redirect_url: str) -> str:
        """
        解析并验证重定向URL的安全�?        
        参数:
            original_url: 原始URL
            redirect_url: 重定向URL
            
        返回:
            完整且安全的URL
        """
        # 解析URL
        orig = urlparse(original_url)
        redirect = urlparse(redirect_url)
        
        # 拒绝危险协议
        if redirect.scheme.lower() in self.FORBIDDEN_SCHEMES:
            raise RedirectSecurityError(f"禁止的重定向协议: {redirect.scheme}")
        
        # 拒绝非HTTP/HTTPS协议
        if redirect.scheme.lower() not in ('http', 'https'):
            raise RedirectSecurityError(f"不支持的重定向协�? {redirect.scheme}")
        
        # 拒绝标准端口范围之外的端�?        if redirect.port is not None and redirect.port not in self.SAFE_PORTS:
            if redirect.port not in range(1024, 49152):  # 非注册端口范�?                raise RedirectSecurityError(f"使用非标准端口的重定�? {redirect.port}")
        
        # 验证域名是否有效
        if not redirect.netloc:
            raise RedirectSecurityError("重定向URL缺少网络位置 (netloc)")
        
        # 解析为绝对URL
        return redirect.geturl()

    def _prepare_redirect_request(self, original_request: Request, redirect_url: str) -> Request:
        """
        准备重定向请求对�?        
        参数:
            original_request: 原始请求对象
            redirect_url: 重定向URL
            
        返回:
            新请求对�?        """
        # 创建新请求对�?        new_req = Request(
            url=redirect_url,
            data=original_request.data,
            headers=self._sanitize_headers(original_request.headers),
            method=original_request.method,
            origin_req_host=original_request.origin_req_host,
            unverifiable=True
        )
        
        # 添加Cookie处理
        if self.parent.cookiejar:
            self.parent.cookiejar.add_cookie_header(new_req)
        
        return new_req

    def _sanitize_headers(self, headers: Dict) -> Dict:
        """
        清理安全敏感的请求头
        
        参数:
            headers: 原始请求�?            
        返回:
            清理后的请求�?        """
        # 需要移除的安全敏感�?        sensitive_headers = {'authorization', 'cookie', 'proxy-authorization'}
        
        # 创建新头字典
        new_headers = {k: v for k, v in headers.items() if k.lower() not in sensitive_headers}
        
        # 添加安全�?        if 'Referer' not in new_headers:
            new_headers['Referer'] = self._get_referrer()
        
        return new_headers

    def _is_url(self, s: str) -> bool:
        """检查字符串是否为有效的URL"""
        return s.startswith(('http://', 'https://', '//'))

    def _get_referrer(self) -> str:
        """获取安全Referrer值（仅域名）"""
        if hasattr(self.parent, 'last_url'):
            parsed = urlparse(self.parent.last_url)
            return f"{parsed.scheme}://{parsed.netloc}/"
        return ""


class SecureHTTPHandler:
    """安全HTTP客户端封�?""
    
    def __init__(self, timeout: int = 10, max_redirects: int = 5, user_agent: str = None):
        """
        初始化HTTP客户�?        
        参数:
            timeout: 请求超时时间(�?
            max_redirects = 最大重定向次数
            user_agent: 用户代理字符�?        """
        import urllib
        import socket
        
        self.timeout = timeout
        self.max_redirects = max_redirects
        self.user_agent = user_agent or RefreshHeaderProcessor.USER_AGENT
        socket.setdefaulttimeout(self.timeout)
        
        # 创建处理器链
        self.processor = RefreshHeaderProcessor(
            max_redirects=self.max_redirects,
            timeout=self.timeout
        )
        
        # 创建安全URL开启器
        self.opener = urllib.request.build_opener(
            self.processor,
            urllib.request.HTTPRedirectHandler,
            urllib.request.HTTPCookieProcessor,
            urllib.request.HTTPHandler,
            urllib.request.HTTPSHandler(context=self._create_ssl_context())
        )
        
        # 添加安全�?        self.opener.addheaders = [
            ('Accept-Language', 'en-US,en;q=0.5'),
            ('Connection', 'keep-alive'),
            ('Pragma', 'no-cache'),
            ('Cache-Control', 'no-cache'),
            ('Referer', ''),
            ('User-Agent', self.user_agent)
        ]
    
    def _create_ssl_context(self):
        """创建配置安全的SSL上下�?""
        import ssl
        ctx = ssl.create_default_context()
        ctx.check_hostname = True
        ctx.verify_mode = ssl.CERT_REQUIRED
        ctx.set_ciphers('ECDHE+AESGCM:ECDHE+CHACHA20:DHE+AESGCM:DHE+CHACHA20:ECDH+AESGCM:DH+AESGCM:'
                        'ECDH+AES:DH+AES:RSA+AESGCM:RSA+AES:!aNULL:!eNULL:!MD5')
        return ctx
    
    def get(self, url: str, headers: Optional[dict] = None) -> Optional[http.client.HTTPResponse]:
        """
        执行安全HTTP GET请求
        
        参数:
            url: 目标URL
            headers: 自定义请求头
            
        返回:
            HTTP响应对象
        """
        req = urllib.request.Request(url, headers=headers or {})
        try:
            return self.opener.open(req, timeout=self.timeout)
        except Exception as e:
            logger.error(f"HTTP请求失败: {type(e).__name__} - {str(e)}")
            return None
    
    def follow_redirects(self, start_url: str) -> Tuple[bool, str, int]:
        """
        跟踪URL的所有重定向
        
        参数:
            start_url: 起始URL
            
        返回:
            (成功状�? 最终URL, 重定向次�?
        """
        current_req = urllib.request.Request(start_url)
        redirect_count = 0
        
        for _ in range(self.max_redirects + 1):
            try:
                with self.opener.open(current_req) as response:
                    # 检查刷新标签但不再跟踪
                    self.processor._redirect_count = redirect_count
                    self.processor._detect_refresh(current_req, response, response.read())
                    
                    if self.processor._redirect_count > redirect_count:
                        logger.info(f"找到但未跟踪额外的刷新（安全限制�?)
                        
                    return True, current_req.get_full_url(), redirect_count
            except urllib.error.HTTPError as he:
                if 300 <= he.code < 400:
                    # 处理标准3XX重定�?                    location = he.headers.get('Location')
                    if not location:
                        logger.error(f"重定向响应中缺少Location�?)
                        return False, current_req.get_full_url(), redirect_count
                    
                    redirect_count += 1
                    logger.info(f"重定�?#{redirect_count}: {current_req.get_full_url()} -> {location}")
                    current_req = urllib.request.Request(location)
                    continue
                return False, current_req.get_full_url(), redirect_count
            except Exception as e:
                logger.error(f"跟踪重定向时出错: {str(e)}")
                return False, current_req.get_full_url(), redirect_count
        
        logger.error(f"达到最大重定向次数: {self.max_redirects}")
        return False, current_req.get_full_url(), redirect_count


# 使用示例
if __name__ == "__main__":
    import sys
    from urllib.request import build_opener
    
    # 测试URL - 在实际应用中替换为需要测试的URL
    TEST_URLS = [
        "https://httpbin.org/redirect-to?url=https%3A%2F%2Fhttpbin.org%2Fheaders", 
        "https://httpbin.org/response-headers?refresh=3;url=https://httpbin.org/html",
        "https://example.com/meta-refresh-page"
    ]
    
    # 配置日志级别
    logger.setLevel(logging.DEBUG)
    
    # 创建安全HTTP客户�?    secure_http = SecureHTTPHandler()
    
    for i, url in enumerate(TEST_URLS, 1):
        print(f"\n=== 测试URL #{i}: {url} ===")
        
        # 获取带有重定向处理的页面
        response = secure_http.get(url)
        if not response:
            print(f"  请求失败: {url}")
            continue
            
        # 显示最终URL
        final_url = response.url
        print(f"  响应URL: {final_url}")
        
        # 显示状态码
        print(f"  状态码: {response.status}")
        
        # 显示响应�?        print("\n  响应�?")
        for h in response.headers.items():
            print(f"    {h[0]}: {h[1]}")
            
        # 跟踪重定向路�?        print("\n  跟踪重定向路�?")
        success, final_url, count = secure_http.follow_redirects(url)
        print(f"    初始URL: {url}")
        print(f"    最终URL: {final_url} (经过{count}次重定向)")
        
        # 显示内容长度
        content = response.read()
        print(f"  内容长度: {len(content)}字节")
        
        # 简单内容检�?        if b"<html" in content[:100]:
            print("  内容类型: HTML")
        elif b"{".encode() in content[:1]:
            print("  内容类型: JSON")
        else:
            print("  内容类型: 未知")
            
        response.close()
