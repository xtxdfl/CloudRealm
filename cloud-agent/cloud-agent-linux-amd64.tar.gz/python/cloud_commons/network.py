#!/usr/bin/env python3
"""
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import http.client
import ssl
import socket
import urllib.request
import urllib.error
from typing import Optional, Tuple, Dict, Any
from cloud_commons import logging_utils

# 安全常量定义
DEFAULT_TIMEOUT = 30  # 默认超时30�?MAX_RETRIES = 3       # 最大重试次�?MIN_TLS_VERSION = getattr(ssl, "PROTOCOL_TLSv1_2", ssl.PROTOCOL_TLSv1)  # 默认使用TLS 1.2+

class SecureHTTPSConnection(http.client.HTTPSConnection):
    """增强型HTTPS连接，提供更好的安全和兼容性支�?""
    def __init__(
        self, 
        host: str, 
        port: Optional[int] = None, 
        *,
        # 安全参数
        tls_version: int = MIN_TLS_VERSION,
        key_file: Optional[str] = None,
        cert_file: Optional[str] = None,
        ca_certs: Optional[str] = None,
        ciphers: Optional[str] = None,
        # 连接参数
        timeout: float = DEFAULT_TIMEOUT,
        source_address: Optional[Tuple[str, int]] = None,
        # 其他选项
        disable_hostname_verification: bool = False,
        **kwargs
    ):
        """
        创建安全的HTTPS连接
        
        :param tls_version: TLS版本 (默认: MIN_TLS_VERSION)
        :param ca_certs: CA证书路径
        :param ciphers: 支持的加密套�?(例如: HIGH:!aNULL:!eNULL:!EXPORT)
        :param disable_hostname_verification: 禁用主机名验�?(安全风险!)
        """
        super().__init__(host, port, key_file=key_file, cert_file=cert_file, timeout=timeout, 
                          source_address=source_address, **kwargs)
        self.tls_version = tls_version
        self.ca_certs = ca_certs
        self.ciphers = ciphers
        self.disable_hostname_verification = disable_hostname_verification

    def connect(self) -> None:
        """建立带安全配置的HTTPS连接"""
        # 创建基本TCP连接
        conn_socket = socket.create_connection(
            (self.host, self.port),
            self.timeout,
            self.source_address
        )
        
        # 配置SSL上下�?        ssl_ctx = ssl.SSLContext(self.tls_version)
        
        # 安全配置
        if self.ca_certs:
            ssl_ctx.load_verify_locations(cafile=self.ca_certs)
            ssl_ctx.verify_mode = ssl.CERT_REQUIRED
        else:
            ssl_ctx.verify_mode = ssl.CERT_NONE
            
        if self.ciphers:
            try:
                ssl_ctx.set_ciphers(self.ciphers)
            except ssl.SSLError as e:
                logging_utils.print_warning_msg(
                    f"Failed to set ciphers '{self.ciphers}': {str(e)}. Using defaults.")

        if self.key_file and self.cert_file:
            ssl_ctx.load_cert_chain(self.cert_file, self.key_file)
            
        # 设置高级选项
        ssl_ctx.check_hostname = not self.disable_hostname_verification
        ssl_ctx.options |= ssl.OP_NO_SSLv2
        ssl_ctx.options |= ssl.OP_NO_SSLv3
        ssl_ctx.options |= ssl.OP_NO_COMPRESSION
        
        # 包装socket
        self.sock = ssl_ctx.wrap_socket(
            conn_socket,
            server_hostname=self.host if not self.disable_hostname_verification else None
        )
        
        # 验证证书
        if ssl_ctx.verify_mode == ssl.CERT_REQUIRED:
            try:
                cert = self.sock.getpeercert()
                if not cert:
                    raise ssl.SSLCertVerificationError(
                        "No certificate returned from server"
                    )
            except Exception as e:
                self.close()
                raise ssl.SSLError(f"Certificate verification failed: {str(e)}")

def get_http_connection(
    host: str,
    port: Optional[int] = None,
    https_enabled: bool = False,
    **kwargs: Dict[str, Any]
) -> http.client.HTTPConnection:
    """
    获取HTTP或HTTPS连接
    
    :param https_enabled: 是否使用HTTPS
    :param kwargs: 传递给SecureHTTPSConnection的额外参�?    :return: HTTPConnection或SecureHTTPSConnection实例
    """
    # 处理默认端口
    if port is None:
        port = 443 if https_enabled else 80
    
    if https_enabled:
        return SecureHTTPSConnection(host, port, **kwargs)
    else:
        return http.client.HTTPConnection(host, port, **kwargs)

def verify_ssl_certificate(
    host: str,
    port: int = 443,
    ca_certs: Optional[str] = None,
    tls_version: int = MIN_TLS_VERSION,
    timeout: float = DEFAULT_TIMEOUT
) -> bool:
    """
    验证主机SSL证书的有效�?    
    :return: 验证是否成功
    """
    try:
        # 创建临时socket
        sock = socket.create_connection((host, port), timeout=timeout)
        
        # 创建SSL上下�?        ssl_ctx = ssl.SSLContext(tls_version)
        ssl_ctx.check_hostname = True
        ssl_ctx.verify_mode = ssl.CERT_REQUIRED
        
        if ca_certs:
            ssl_ctx.load_verify_locations(cafile=ca_certs)
        
        # 启用安全选项
        ssl_ctx.options |= ssl.OP_NO_SSLv2
        ssl_ctx.options |= ssl.OP_NO_SSLv3
        
        # 验证证书
        with ssl_ctx.wrap_socket(sock, server_hostname=host) as secure_sock:
            cert = secure_sock.getpeercert()
            if not cert:
                logging_utils.print_warning_msg(f"No SSL certificate for {host}:{port}")
                return False
                
            # 证书主题验证
            common_name = cert.get("subjectAltName", [('CN', host)])[0][1]
            if common_name != host:
                logging_utils.print_warning_msg(
                    f"Certificate CN mismatch ({common_name} vs {host})"
                )
                
        return True
        
    except ssl.SSLCertVerificationError as e:
        logging_utils.print_error_msg(f"Certificate verification failed: {str(e)}")
        return False
    except ssl.SSLError as e:
        logging_utils.print_error_msg(f"SSL error: {str(e)}")
        return False
    except socket.error as e:
        logging_utils.print_error_msg(f"Connection error: {str(e)}")
        return False

def configure_global_proxy_settings(
    proxy_url: Optional[str] = None,
    ignore_system_proxy: bool = False
) -> None:
    """
    配置全局代理设置
    
    :param proxy_url: 自定义代理URL (格式: http://proxy.example.com:8080)
    :param ignore_system_proxy: 是否忽略系统级代理设�?    """
    handlers = []
    
    # 处理自定义代�?    if proxy_url:
        parsed = urllib.parse.urlparse(proxy_url)
        proxy_dict = {parsed.scheme: proxy_url}
        proxy_handler = urllib.request.ProxyHandler(proxy_dict)
        handlers.append(proxy_handler)
    elif ignore_system_proxy:
        proxy_handler = urllib.request.ProxyHandler({})
        handlers.append(proxy_handler)
    
    # 配置安全协议
    https_handler = urllib.request.HTTPSHandler(
        context=ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
    )
    handlers.append(https_handler)
    
    # 创建并安装opener
    opener = urllib.request.build_opener(*handlers)
    urllib.request.install_opener(opener)

def get_global_tls_context(
    min_version: int = MIN_TLS_VERSION,
    ca_certs: Optional[str] = None,
    ciphers: Optional[str] = None
) -> ssl.SSLContext:
    """
    获取全局默认TLS上下�?    
    :param min_version: 最小TLS版本
    :param ca_certs: 自定义CA证书路径
    :param ciphers: 自定义密码套�?    :return: 配置好的SSLContext
    """
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    
    # 设置最小协议版�?    if min_version:
        context.minimum_version = min_version
    
    # 禁用不安全协�?    context.options |= ssl.OP_NO_SSLv2
    context.options |= ssl.OP_NO_SSLv3
    context.options |= ssl.OP_NO_TLSv1 if hasattr(ssl, "OP_NO_TLSv1") else 0
    context.options |= ssl.OP_NO_TLSv1_1 if hasattr(ssl, "OP_NO_TLSv1_1") else 0
    
    # 安全套件配置
    if ciphers:
        context.set_ciphers(ciphers)
    else:
        # 使用现代化安全套�?        context.set_ciphers("ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:"
                           "ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:"
                           "ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256")
    
    # 证书验证
    if ca_certs:
        context.load_verify_locations(cafile=ca_certs)
        context.verify_mode = ssl.CERT_REQUIRED
    else:
        context.load_default_certs()
        context.verify_mode = ssl.CERT_REQUIRED
        
    # 其他安全优化
    context.check_hostname = True
    context.verify_flags = ssl.VERIFY_X509_STRICT
    
    return context

def retry_connection(
    func,
    max_retries=MAX_RETRIES,
    backoff_factor=1.0,
    status_forcelist=(500, 502, 503, 504),
):
    """连接重试装饰�?""
    def wrapper(*args, **kwargs):
        for attempt in range(1, max_retries + 1):
            try:
                return func(*args, **kwargs)
            except (http.client.HTTPException, socket.error) as e:
                if attempt < max_retries and (not status_forcelist or getattr(e, "status", None) in status_forcelist):
                    sleep_time = backoff_factor * (2 ** (attempt - 1))
                    logging_utils.print_warning_msg(
                        f"Connection failed: {str(e)}. Retrying in {sleep_time:.1f}s (attempt {attempt}/{max_retries})"
                    )
                    time.sleep(sleep_time)
                else:
                    raise
    return wrapper

# 兼容函数别名
reconfigure_urllib2_opener = configure_global_proxy_settings
check_ssl_certificate_and_return_ssl_version = verify_ssl_certificate
