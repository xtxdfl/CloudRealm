#!/usr/bin/env python3
"""
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import base64
import getpass
import os
import stat
import logging
import hashlib
import tempfile
import shutil
import contextlib
from collections import namedtuple
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Callable, Iterable, Union

from cloud_commons.constants import AGENT_TMP_DIR
from resource_management.core import sudo
from resource_management.core.logger import Logger
from resource_management.core.resources.klist import Klist, KlistError
from resource_management.core.resources.system import Directory, File
from resource_management.core.source import InlineTemplate, Template

# 增强的加密类型映射表 - 包含最新标�?ENCRYPTION_FAMILY_MAP = {
    "aes": [
        "aes256-cts-hmac-sha1-96",
        "aes128-cts-hmac-sha1-96",
        "aes256-cts-hmac-sha384-192",
        "aes128-cts-hmac-sha256-128",
        "aes256-cts-hmac-sha512-192",
        "aes128-cts-hmac-sha512-128"
    ],
    "rc4": ["rc4-hmac"],
    "camellia": [
        "camellia256-cts-cmac",
        "camellia128-cts-cmac",
        "camellia256-cts-sha384",
        "camellia128-cts-sha256"
    ],
    "des3": [
        "des3-cbc-sha1",
        "des3-cbc-sha1-kd"
    ],
    "des": [
        "des-cbc-crc",
        "des-cbc-md5",
        "des-cbc-md4"
    ],
    "strong": [
        "aes256-cts-hmac-sha384-192",
        "aes128-cts-hmac-sha256-128",
        "camellia256-cts-cmac",
        "camellia128-cts-cmac"
    ],
    "fips": [
        "aes256-cts-hmac-sha384-192",
        "aes128-cts-hmac-sha256-128",
        "aes256-cts-hmac-sha512-192",
        "aes128-cts-hmac-sha512-128"
    ]
}

class KerberosSecurityLevel:
    """Kerberos安全级别配置�?""
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    FIPS = 4

    DEFAULT = MEDIUM
    MINIMUM = LOW

class KerberosConfigValidator:
    """Kerberos配置验证工具"""
    
    @staticmethod
    def validate_krb5_config(config_content: str) -> Tuple[bool, str]:
        """
        验证krb5.conf内容的完整�?        :param config_content: 配置内容
        :return: (有效�? 错误消息)
        """
        required_sections = ["libdefaults", "realms", "domain_realm"]
        errors = []
        
        # 基本结构检�?        if "[libdefaults]" not in config_content:
            errors.append("Missing required section: [libdefaults]")
        
        realms_present = "[realms]" in config_content
        domains_present = "[domain_realm]" in config_content
        
        # 默认域检�?        if "default_realm" not in config_content.lower():
            errors.append("Missing required parameter: default_realm")
        
        # 如果缺少实际领域配置
        missing_realms = []
        if realms_present:
            realm_names = re.findall(r"\[realms\]\s*([a-zA-Z0-9.]+)\s*=\s*{", config_content)
            if not realm_names:
                errors.append("No realms defined in [realms] section")
        else:
            missing_realms.append("[realms]")
            
        if domains_present:
            domain_mappings = re.findall(r"\[domain_realm\]\s*([^\s]+)\s*=\s*([a-zA-Z0-9.]+)", config_content)
            if not domain_mappings:
                errors.append("No mappings defined in [domain_realm] section")
        else:
            missing_realms.append("[domain_realm]")
            
        if errors:
            return False, "; ".join(errors)
        
        return True, "Configuration appears valid"

class KerberosError(Exception):
    """Kerberos操作基础异常�?""
    def __init__(self, message: str, severity: int = logging.ERROR):
        super().__init__(message)
        self.severity = severity
        self.message = message
        
    def __str__(self):
        return f"KerberosError: {self.message} (severity={self.severity})"

class KerberosKeytabError(KerberosError):
    """keytab文件操作异常"""
    pass

class KerberosKeytabIntegrityError(KerberosKeytabError):
    """keytab文件完整性检查失败异�?""
    pass

class MissingKeytabs:
    """增强的缺失keytab检测工�?""
    
    class Identity(namedtuple("Identity", ["principal", "keytab_file_path", "owner", "group"])):
        """keytab身份信息�?""
        
        __slots__ = ()  # 优化内存使用
        
        @staticmethod
        def from_kerberos_record(item: Dict, hostname: str) -> "Identity":
            """
            从Kerberos记录创建Identity对象
            :param item: Kerberos配置�?            :param hostname: 主机�?            :return: Identity实例
            """
            principal = get_property_value(item, "principal")
            if not principal:
                raise ValueError("Principal value is missing or empty")
                
            # 使用现代字符串格式化替换_HOST
            formatted_principal = principal.replace("_HOST", hostname)
            
            return MissingKeytabs.Identity(
                principal=formatted_principal,
                keytab_file_path=get_property_value(item, "keytab_file_path"),
                owner=get_property_value(item, "keytab_file_owner_name") or getpass.getuser(),
                group=get_property_value(item, "keytab_file_group_name") or "root"
            )

        def __str__(self) -> str:
            return f"Principal: {self.principal} | Keytab: {self.keytab_file_path} | Owner: {self.owner} | Group: {self.group}"

    @classmethod
    def from_kerberos_records(
        cls,
        kerberos_records: Iterable[Dict],
        hostname: str
    ) -> "MissingKeytabs":
        """
        从Kerberos记录集合创建MissingKeytabs实例
        :param kerberos_records: Kerberos记录列表
        :param hostname: 主机�?        :return: MissingKeytabs实例
        """
        missing = set()
        
        for record in kerberos_records or []:
            try:
                identity = cls.Identity.from_kerberos_record(record, hostname)
                
                if not cls.keytab_exists(identity.keytab_file_path):
                    missing.add(identity)
                elif not cls.keytab_has_principal(identity.principal, identity.keytab_file_path):
                    missing.add(identity)
            except Exception as e:
                Logger.warning(f"Skipping invalid Kerberos record: {str(e)}")
                continue
        
        return cls(missing)

    @staticmethod
    def keytab_exists(keytab_path: str) -> bool:
        """
        检查keytab文件是否存在
        :param keytab_path: keytab文件路径
        :return: 是否存在
        """
        if not keytab_path:
            return False
            
        return sudo.path_exists(keytab_path)

    @staticmethod
    def keytab_has_principal(principal: str, keytab_path: str) -> bool:
        """
        检查keytab是否包含指定principal
        :param principal: 要检查的principal
        :param keytab_path: keytab文件路径
        :return: 是否包含
        """
        if not keytab_path or not principal:
            return False
            
        try:
            klist = Klist.find_in_search_path()
            principals = klist.list_principals(keytab_path)
            return principal in principals
        except KlistError as e:
            Logger.error(f"Klist error when checking keytab: {str(e)}")
            return False

    def __init__(self, items: Optional[set]) -> None:
        """
        初始化MissingKeytabs实例
        :param items: 缺失的keytab集合
        """
        self.items = items or set()

    def is_empty(self) -> bool:
        return len(self.items) == 0

    def as_dict(self) -> List[Dict]:
        """转换为字典列表序列化"""
        return [i._asdict() for i in self.items] if self.items else []

    def __str__(self) -> str:
        """友好的缺失keytab字符串表�?""
        if not self.items:
            return "No missing keytabs"
            
        items_str = "\n".join(f"- {str(item)}" for item in self.items)
        return f"Missing keytabs ({len(self.items)}):\n{items_str}"

class KeytabManager:
    """专业的keytab文件管理工具"""
    
    @staticmethod
    def generate_keytab_hash(keytab_content: bytes) -> str:
        """为keytab内容生成SHA-256哈希"""
        return hashlib.sha256(keytab_content).hexdigest()
    
    @staticmethod
    def create_temp_keytab(content: bytes) -> Path:
        """创建临时keytab文件用于验证"""
        temp_dir = tempfile.mkdtemp(prefix="krb_keytab_")
        temp_path = Path(temp_dir) / "temp.keytab"
        temp_path.write_bytes(content)
        return temp_path
    
    @staticmethod
    def verify_keytab(content: bytes) -> Tuple[bool, str]:
        """验证keytab文件完整性和格式"""
        try:
            temp_keytab = KeytabManager.create_temp_keytab(content)
            
            # 尝试用klist读取keytab
            klist = Klist.find_in_search_path()
            if klist.list_principals(str(temp_keytab)):
                # 成功读取
                shutil.rmtree(temp_keypath.parent)
                return True, "Keytab is valid"
        except Exception as e:
            error_msg = f"Keytab verification failed: {str(e)}"
            Logger.error(error_msg)
            return False, error_msg
            
        return False, "Keytab does not contain any principals"

class KerberosUtils:
    """Kerberos工具函数集合"""
    
    @staticmethod
    @contextlib.contextmanager
    def secure_temp_dir():
        """创建安全的临时目�?""
        temp_dir = tempfile.mkdtemp(prefix="krb_secure_")
        try:
            os.chmod(temp_dir, 0o700)  # 仅所有者可访问
            yield Path(temp_dir)
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)
    
    @staticmethod
    def build_file_permissions(
        owner_access: str, 
        group_access: str, 
        others_access: str = "no"
    ) -> int:
        """
        构建文件权限模式
        :param owner_access: 所有者权�?(rw, r, w, no)
        :param group_access: 组权�?        :param others_access: 其他用户权限
        :return: 权限模式整数
        """
        mode = 0
        
        # 所有者权�?        if "r" in owner_access:
            mode |= stat.S_IRUSR
        if "w" in owner_access:
            mode |= stat.S_IWUSR
            
        # 组权�?        if "r" in group_access:
            mode |= stat.S_IRGRP
        if "w" in group_access:
            mode |= stat.S_IWGRP
            
        # 其他用户权限
        if "r" in others_access:
            mode |= stat.S_IROTH
        if "w" in others_access:
            mode |= stat.S_IWOTH
            
        return mode

    @classmethod
    def resolve_encryption_types(
        cls, 
        enc_types_str: Optional[str], 
        security_level: int = KerberosSecurityLevel.DEFAULT
    ) -> str:
        """
        解析加密类型字符�?        :param enc_types_str: 加密类型字符�?        :param security_level: 安全级别，用于自动调�?        :return: 解析后的加密类型字符�?        """
        if not enc_types_str:
            # 默认使用MEDIUM安全级别
            return cls.get_default_encryption_types(security_level)
            
        # 支持多种输入格式
        if "," in enc_types_str:
            enc_list = enc_types_str.split(",")
        else:
            enc_list = enc_types_str.split()
            
        # 解决加密家族
        resolved_enc_types = cls.resolve_encryption_family_list(enc_list)
        
        # 根据安全级别过滤
        filtered_enc_types = cls.filter_encryption_types_by_security(
            resolved_enc_types,
            security_level
        )
        
        return " ".join(filtered_enc_types)

    @classmethod
    def resolve_encryption_family_list(cls, enc_types_list: List[str]) -> List[str]:
        """
        解析加密类型列表到具体算�?        :param enc_types_list: 加密类型列表
        :return: 解析后的加密算法列表
        """
        result = []
        for enc_type in enc_types_list:
            clean_type = enc_type.strip().lower()
            if clean_type in ENCRYPTION_FAMILY_MAP:
                result.extend(ENCRYPTION_FAMILY_MAP[clean_type])
            elif clean_type in [
                algo for family in ENCRYPTION_FAMILY_MAP.values() 
                for algo in family
            ]:
                result.append(clean_type)
            else:
                Logger.warning(f"Unsupported encryption type: {enc_type}")
        return list(set(result))  # 去重

    @classmethod
    def filter_encryption_types_by_security(
        cls, 
        enc_types: List[str],
        security_level: int
    ) -> List[str]:
        """
        根据安全级别过滤加密算法
        :param enc_types: 加密算法列表
        :param security_level: 安全级别
        :return: 过滤后的加密算法列表
        """
        # 不安全算法黑名单
        weak_algos = set([
            "des-cbc-crc", "des-cbc-md4", "des-cbc-md5", 
            "rc4-hmac", "des3-cbc-sha1"
        ])
        
        # 根据安全级别过滤
        if security_level >= KerberosSecurityLevel.HIGH:
            return list(set(enc_types) - weak_algos)
        elif security_level == KerberosSecurityLevel.MEDIUM:
            return [enc for enc in enc_types if enc not in weak_algos]
        else:
            return enc_types  # LOW级别不过�?
    @classmethod
    def get_default_encryption_types(
        cls,
        security_level: int = KerberosSecurityLevel.DEFAULT
    ) -> str:
        """
        获取默认加密类型配置
        :param security_level: 安全级别
        :return: 默认加密类型字符�?        """
        if security_level >= KerberosSecurityLevel.FIPS:
            return " ".join(ENCRYPTION_FAMILY_MAP["fips"])
        elif security_level == KerberosSecurityLevel.HIGH:
            return " ".join(ENCRYPTION_FAMILY_MAP["strong"])
        else:
            # 默认中等安全级别组合
            return "aes256-cts-hmac-sha1-96 aes128-cts-hmac-sha1-96 des3-cbc-sha1"

def write_krb5_conf(
    krb5_conf_path: str, 
    krb5_conf_template: str, 
    template_vars: Dict = None
) -> None:
    """
    增强版Kerberos配置文件写入
    :param krb5_conf_path: 配置文件路径
    :param krb5_conf_template: 配置模板
    :param template_vars: 模板变量
    """
    try:
        # 创建父目�?        krb5_conf_dir = os.path.dirname(krb5_conf_path)
        Directory(
            krb5_conf_dir,
            owner="root",
            group="root",
            mode=0o755,
            create_parents=True,
            cd_access="a",
        )
        
        # 渲染配置内容
        content = Template(krb5_conf_template, extra_imports=[
            "from kerberos_utils import KerberosUtils"
        ]).render(template_vars or {})

        # 高级配置验证
        is_valid, validation_msg = KerberosConfigValidator.validate_krb5_config(content)
        if not is_valid:
            raise KerberosError(f"Invalid krb5.conf configuration: {validation_msg}")
        
        # 安全写入配置文件
        with tempfile.NamedTemporaryFile("w", delete=False, dir=krb5_conf_dir) as temp_file:
            temp_file.write(content)
            temp_file_path = temp_file.name
            
        # 设置权限并移动到目标位置
        os.chmod(temp_file_path, 0o644)
        os.chown(temp_file_path, sudo._get_uid("root"), sudo._get_gid("root"))
        sudo.rename(temp_file_path, krb5_conf_path)

        Logger.info(f"Successfully updated Kerberos configuration: {krb5_conf_path}")
        
    except Exception as e:
        Logger.error(f"Failed to write krb5.conf: {str(e)}")
        # 清理残留文件
        if temp_file_path and sudo.path_exists(temp_file_path):
            sudo.unlink(temp_file_path)
        raise

def clear_tmp_cache() -> None:
    """安全清理临时缓存目录"""
    tmp_dir = AGENT_TMP_DIR or tempfile.gettempdir()
    curl_krb_cache_path = os.path.join(tmp_dir, "curl_krb_cache")
    
    if sudo.path_exists(curl_krb_cache_path):
        Logger.info(f"Clearing temporary Kerberos cache: {curl_krb_cache_path}")
        with contextlib.suppress(Exception):
            sudo.rmtree(curl_krb_cache_path)
    else:
        Logger.debug(f"Temporary Kerberos cache does not exist: {curl_krb_cache_path}")

def write_keytab_file(
    keytab_records: Iterable[Dict],
    output_hook: Optional[Callable] = None,
    security_level: int = KerberosSecurityLevel.DEFAULT
) -> None:
    """
    增强版keytab文件写入
    :param keytab_records: keytab记录集合
    :param output_hook: 每次写入成功后的回调函数
    :param security_level: 密钥导出安全级别
    """
    if not keytab_records:
        Logger.info("No keytab records to process")
        return
        
    stats = {"success": 0, "errors": 0}
    
    for record in keytab_records:
        try:
            KerberosUtils.process_keytab_record(
                record, 
                output_hook,
                security_level=security_level
            )
            stats["success"] += 1
        except KerberosKeytabError as e:
            Logger.error(str(e))
            stats["errors"] += 1
            
    Logger.info(f"Keytab processing complete: {stats['success']} success, {stats['errors']} errors")

def delete_keytab_file(
    keytab_records: Iterable[Dict], 
    output_hook: Optional[Callable] = None
) -> None:
    """
    安全删除keytab文件
    :param keytab_records: keytab记录集合
    :param output_hook: 每次删除成功后的回调函数
    """
    stats = {"deleted": 0, "errors": 0}
    
    for record in keytab_records:
        try:
            keytab_path = get_property_value(record, "keytab_file_path")
            principal = get_property_value(record, "principal")
            
            if not keytab_path:
                Logger.warning(f"Skipping keytab deletion due to empty path for principal: {principal}")
                continue
                
            if not sudo.path_exists(keytab_path):
                Logger.info(f"Keytab does not exist, skipping deletion: {keytab_path}")
                continue
                
            # 安全删除keytab文件
            sudo.unlink(keytab_path)
            Logger.info(f"Successfully deleted keytab: {keytab_path}")
            
            if callable(output_hook):
                output_hook(principal, keytab_path)
                
            stats["deleted"] += 1
            
        except Exception as e:
            Logger.error(f"Failed to delete keytab: {str(e)}")
            stats["errors"] += 1
            continue
            
    Logger.info(f"Keytab deletion complete: {stats['deleted']} deleted, {stats['errors']} errors")

def find_missing_keytabs(
    keytab_records: Iterable[Dict],
    hostname: str,
    output_hook: Optional[Callable] = None
) -> Dict:
    """
    查找缺失的keytab文件
    :param keytab_records: keytab记录集合
    :param hostname: 主机�?    :param output_hook: 结果回调函数
    :return: 缺失keytab统计信息
    """
    try:
        missing = MissingKeytabs.from_kerberos_records(keytab_records, hostname)
        Logger.info(str(missing))
        
        if callable(output_hook):
            output_hook(missing.as_dict())
            
        return missing.as_dict()
    except Exception as e:
        Logger.error(f"Error finding missing keytabs: {str(e)}")
        return {"error": str(e)}

def rotate_keytabs(
    keytab_records: Iterable[Dict],
    hostname: str,
    security_level: int = KerberosSecurityLevel.DEFAULT
) -> None:
    """
    Keytab轮换工具 - 先删除旧keytab，再写入新keytab
    :param keytab_records: keytab记录集合
    :param hostname: 主机�?    :param security_level: 安全级别
    """
    # 1. 删除旧keytab文件
    delete_keytab_file(keytab_records)
    
    # 2. 短暂延迟确保删除完成
    sleep(1)
    
    # 3. 写入新keytab文件
    write_keytab_file(keytab_records, security_level=security_level)
    
    # 4. 验证新keytab
    missing = find_missing_keytabs(keytab_records, hostname)
    if missing:
        message = f"Keytab rotation completed with issues: {len(missing)} missing keytabs"
        Logger.warning(message)
        raise KerberosKeytabError(message)
        
    Logger.info("Keytab rotation completed successfully")

def generate_kdc_conf(
    conf_path: str,
    kdc_type: str = "heimdal",
    encryption_types: Optional[str] = None,
    max_ticket_life: str = "24h",
    max_renewable_life: str = "7d"
) -> None:
    """
    生成增强版KDC配置文件
    :param conf_path: 配置文件路径
    :param kdc_type: KDC类型 (heimdal|mit)
    :param encryption_types: 加密类型列表
    :param max_ticket_life: 最大票据生命周�?    :param max_renewable_life: 最大可续约生命周期
    """
    # 动态加载模�?    template_file = {
        "heimdal": "kdc.conf.heimdal.j2",
        "mit": "kdc.conf.mit.j2"
    }.get(kdc_type.lower(), "kdc.conf.mit.j2")
    
    # 解析加密类型
    resolver = KerberosUtils.resolve_encryption_types(encryption_types)
    
    # 渲染配置
    context = {
        "encryption_types": resolver,
        "max_ticket_life": max_ticket_life,
        "max_renewable_life": max_renewable_life
    }
    
    # 写入配置文件
    write_krb5_conf(conf_path, template_file, context)

def get_keytab_statistics() -> Dict[str, int]:
    """
    获取系统keytab使用情况统计
    :return: 统计信息字典
    """
    stats = {
        "total_keytabs": 0,
        "keytabs_under_rbac": 0,
        "keytabs_with_incorrect_perms": 0,
        "keytabs_missing": 0,
        "keytabs_revoked": 0
    }
    
    # 实现逻辑扫描文件系统和Kerberos数据�?    # 注意：在实际实现中需要与KDC交互
    
    return stats

def verify_keytab_integrity(
    principal: str,
    keytab_path: str,
    keytab_content: bytes = None
) -> Dict:
    """
    验证keytab完整�?    :param principal: 预期Principal
    :param keytab_path: keytab文件路径
    :param keytab_content: 可选keytab内容（用于远程验证）
    :return: 验证结果
    """
    verifier = KerberosIntegrityVerifier(principal, keytab_path)
    if keytab_content:
        return verifier.verify_content(keytab_content)
    return verifier.verify_file()

class KerberosIntegrityVerifier:
    """Keytab完整性验证工�?""
    
    def __init__(self, principal: str, keytab_path: str):
        self.principal = principal
        self.keytab_path = keytab_path
        self.klist = Klist.find_in_search_path()
    
    def verify_file(self) -> Dict:
        """验证文件系统中的keytab"""
        # 1. 检查文件是否存�?        if not os.path.exists(self.keytab_path):
            return {
                "valid": False,
                "reason": "Keytab file does not exist",
                "error_code": "missing_file"
            }
        
        # 2. 检查文件权�?        file_stat = os.stat(self.keytab_path)
        if file_stat.st_mode & 0o777 > 0o600:
            return {
                "valid": False,
                "reason": "Insecure file permissions",
                "mode": oct(file_stat.st_mode),
                "recommended_mode": "0o600"
            }
        
        # 3. 检查是否包含principal
        if not self._keytab_contains_principal():
            return {
                "valid": False,
                "reason": f"Principal {self.principal} not found in keytab"
            }
            
        # 4. 检查密钥版�?        kvno_info = self._get_key_version_numbers()
        if kvno_info.get("status") != "ok":
            return {
                "valid": False,
                "reason": "Keytab contains invalid or outdated keys",
                "kvno_info": kvno_info
            }
            
        return {"valid": True}
    
    def verify_content(self, keytab_content: bytes) -> Dict:
        """验证提供的keytab内容"""
        try:
            # 1. 检查是否包含principal
            with tempfile.NamedTemporaryFile(delete=True) as temp_keytab:
                temp_keytab.write(keytab_content)
                temp_keytab.flush()
                
                if not self.klist.keytab_contains_principal(
                    temp_keytab.name, 
                    self.principal
                ):
                    return {
                        "valid": False,
                        "reason": f"Principal {self.principal} not found"
                    }
                    
            # 2. 解析内容结构
            # (此处可以添加更严格的内容验证)
            return {"valid": True}
        except Exception as e:
            return {
                "valid": False,
                "reason": f"Keytab content verification failed: {str(e)}"
            }
    
    def _keytab_contains_principal(self) -> bool:
        """检查keytab是否包含principal"""
        try:
            principals = self.klist.list_principals(self.keytab_path)
            return self.principal in principals
        except KlistError as e:
            raise KerberosKeytabIntegrityError(
                f"Cannot read keytab principals: {str(e)}"
            )
    
    def _get_key_version_numbers(self) -> Dict:
        """获取keytab中的密钥版本信息"""
        try:
            result = self.klist.keytab_version_info(self.keytab_path)
            
            # 检查是否有旧版本key
            if result.get("oldest_kvno") < result.get("newest_kvno"):
                return {
                    "status": "warning",
                    "message": "Keytab contains outdated keys",
                    "kvno_range": [
                        result["oldest_kvno"], 
                        result["newest_kvno"]
                    ]
                }
                
            return {"status": "ok", "kvno": result["current_kvno"]}
        except KlistError as e:
            return {
                "status": "error",
                "message": str(e)
            }

class KerberosAuditLogger:
    """Kerberos审计日志工具"""
    
    @staticmethod
    def log_keytab_creation(identity: MissingKeytabs.Identity) -> None:
        """记录keytab创建事件"""
        audit_message = f"KEYTAB CREATED: {identity.principal} at {identity.keytab_file_path}"
        Logger.audit(audit_message)
        
    @staticmethod
    def log_keytab_deletion(principal: str, keytab_path: str) -> None:
        """记录keytab删除事件"""
        audit_message = f"KEYTAB DELETED: {principal} from {keytab_path}"
        Logger.audit(audit_message)
        
    @staticmethod
    def log_kerberos_config_change(config_path: str, change_type: str) -> None:
        """记录Kerberos配置变更"""
        audit_message = f"KERBEROS CONFIG CHANGE: {change_type} for {config_path}"
        Logger.audit(audit_message)
