#!/usr/bin/env python3
"""
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import re
import os
import shutil
import resource
import logging
import platform
import subprocess
import getpass as gp
import pwd
import errno
from pathlib import Path
from functools import wraps
from string import Template
from cloud_commons import OSCheck
from cloud_commons.exceptions import FatalException
from cloud_commons.os_ops import (
    os_run_os_command, 
    os_change_owner,
    os_set_file_permissions,
    os_set_open_files_limit,
    os_is_service_exist
)

# 配置日志系统
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger("FileOps")

def os_aware(func):
    """装饰器：自动化处理操作系统差�?""
    @wraps(func)
    def wrapper(*args, **kwargs):
        # 在Windows上跳过类Unix操作
        if OSCheck.is_windows_family() and func.__name__ in [
            'change_owner', 'get_file_owner', 'current_user', 
            'get_used_ram', 'set_unix_permissions', 'is_unix_service_exist'
        ]:
            logger.debug(f"Skipping Unix-only function {func.__name__} on Windows")
            return None
        try:
            return func(*args, **kwargs)
        except OSError as e:
            logger.warning(f"Operation failed: {func.__name__}, error: {str(e)}")
            raise FatalException(e.errno, f"OS operation failed: {e.strerror}")
    return wrapper

@os_aware
def current_user() -> str:
    """获取当前用户�?(Unix系统)"""
    if OSCheck.is_windows_family():
        return os.getlogin()
    return pwd.getpwuid(os.geteuid()).pw_name

@os_aware
def get_used_ram() -> int:
    """
    获取当前进程使用的物理内�?(RSS)
    
    返回:
        int: 使用的RAM (KB)
    """
    if OSCheck.is_windows_family():
        import psutil
        return psutil.Process().memory_info().rss // 1024
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss

def is_valid_filepath(filepath: str, require_exists: bool = True) -> bool:
    """
    验证文件路径是否有效
    
    参数:
        filepath: 要验证的路径
        require_exists: 是否需要文件存�?        
    返回:
        bool: 路径是否有效
    """
    try:
        path = Path(filepath)
        if require_exists and not path.exists():
            logger.error(f"Path does not exist: {filepath}")
            return False
        if not path.is_file():
            logger.error(f"Not a regular file: {filepath}")
            return False
        return True
    except Exception as e:
        logger.exception(f"Invalid path: {filepath}")
        return False

def safe_quote_path(filepath: str) -> str:
    """
    安全引用路径 (当路径包含空格时添加引号)
    
    参数:
        filepath: 要引用的路径
        
    返回:
        str: 安全引用的路�?    """
    if " " in filepath and not (filepath.startswith('"') and filepath.endswith('"')):
        return f'"{filepath}"'
    return filepath

def normalize_file_uri(file_uri: str) -> str:
    """
    规范化文件URI
    """
    # 移除file://方案前缀
    if file_uri.startswith("file://"):
        file_uri = file_uri[7:]
    
    # 跨平台路径分隔符处理
    if OSCheck.is_windows_family():
        # Windows上保留反斜杠
        file_uri = file_uri.replace("/", "\\")
    else:
        # Unix上统一使用斜杠
        file_uri = file_uri.replace("\\", "/")
    
    # 移除多余的斜�?    file_uri = re.sub(r'/+', '/', file_uri)
    
    # 处理Windows驱动器前缀
    if OSCheck.is_windows_family() and re.match(r'^[a-zA-Z]:/', file_uri):
        file_uri = file_uri[0] + ":/" + file_uri[3:]
    
    return file_uri

def locate_file(
    filename: str, 
    search_path: str = None, 
    pathsep: str = os.pathsep
) -> str:
    """
    在指定搜索路径中查找文件
    
    参数:
        filename: 要查找的文件�?        search_path: 搜索路径 (默认为环境变量PATH)
        pathsep: 路径分隔�?(默认为系统分隔符)
        
    返回:
        str: 文件的完整路�?(如果找到)
        None: 未找�?    """
    if search_path is None:
        search_path = os.environ.get("PATH", "")
    
    # 考虑文件名本身已经是完整路径的情�?    if os.path.isabs(filename) and os.path.exists(filename):
        return os.path.abspath(filename)
    
    for directory in search_path.split(pathsep):
        # 跳过空目�?        if not directory:
            continue
            
        candidate = os.path.join(directory, filename)
        # 解决符号链接问题
        if os.path.exists(candidate):
            return os.path.abspath(candidate)
    
    return None

def copy_file(
    src: str, 
    dest: str, 
    backup_existing: bool = False,
    preserve_metadata: bool = True
) -> None:
    """
    复制文件 (安全版本)
    
    参数:
        src: 源文件路�?        dest: 目标文件路径
        backup_existing: 是否备份目标文件 (如果已存�?
        preserve_metadata: 是否保留文件元数�?    """
    src_path = Path(src)
    dest_path = Path(dest)
    
    # 验证源文�?    if not is_valid_filepath(src):
        raise FatalException(
            errno.ENOENT, 
            f"Source file does not exist: {src}"
        )
    
    # 备份已存在的目标文件
    if dest_path.exists() and backup_existing:
        backup_path = dest_path.with_suffix(f"{dest_path.suffix}.bak")
        dest_path.rename(backup_path)
        logger.info(f"Backup created: {backup_path}")
    
    try:
        # 选择复制方法
        if preserve_metadata:
            shutil.copy2(src, dest)
        else:
            shutil.copy(src, dest)
            
        logger.info(f"Copied {src} to {dest}")
    except OSError as e:
        if e.errno == errno.ENOSPC:
            errmsg = (
                "Disk space exhausted while copying file. "
                f"Required: {os_path.getsize(src)} bytes, Available: {shutil.disk_usage(dest).free} bytes"
            )
            raise FatalException(errno.ENOSPC, errmsg)
        raise FatalException(e.errno, f"File copy failed: {e.strerror}")

def copy_files(
    src_files: list, 
    dest_dir: str, 
    fail_on_error: bool = True
) -> list:
    """
    批量复制文件到目标目�?    
    参数:
        src_files: 源文件列�?        dest_dir: 目标目录
        fail_on_error: 是否在遇到错误时终止
        
    返回:
        list: 成功复制的文件列�?    """
    dest_dir = Path(dest_dir)
    # 确保目标目录存在
    dest_dir.mkdir(parents=True, exist_ok=True)
    
    success_list = []
    error_list = []
    
    for src in src_files:
        try:
            # 只复制实际存在的文件
            src_path = Path(src)
            if src_path.is_dir():
                logger.warning(f"Skipping directory: {src}. Use copy_directory for directories.")
                continue
                
            dest = dest_dir / src_path.name
            copy_file(src, dest)
            success_list.append(str(dest))
        except Exception as e:
            error_list.append((src, str(e)))
            if fail_on_error:
                raise
            else:
                logger.error(f"Failed to copy {src}: {str(e)}")
    
    return success_list

def remove_file(file_path: str) -> None:
    """
    安全删除文件
    
    参数:
        file_path: 要删除的文件路径
    """
    path = Path(file_path)
    if not path.exists():
        logger.debug(f"File does not exist, skip removal: {file_path}")
        return
    
    try:
        if path.is_file():
            path.unlink()
            logger.info(f"Removed file: {file_path}")
        elif path.is_dir():
            logger.error(f"Cannot remove directory with remove_file: {file_path}")
            raise FatalException(
                errno.EISDIR,
                f"Path is a directory: {file_path}. Use remove_directory instead."
            )
        else:
            logger.error(f"Unsupported file type: {file_path}")
            raise FatalException(
                errno.EINVAL,
                f"Unsupported file type: {file_path}"
            )
    except OSError as e:
        if e.errno == errno.EACCES:
            raise FatalException(
                errno.EACCES,
                f"Permission denied when removing: {file_path}"
            )
        raise FatalException(
            e.errno,
            f"Failed to remove file: {e.strerror}"
        )

@os_aware
def set_unix_permissions(
    file_path: str, 
    permissions: int, 
    user: str = None, 
    group: str = None,
    recursive: bool = False
) -> None:
    """
    设置Unix文件权限和所有权
    
    参数:
        file_path: 文件或目录路�?        permissions: 八进制权�?(�?o644)
        user: 要设置的用户
        group: 要设置的�?        recursive: 是否递归
    """
    path = Path(file_path)
    
    # 设置权限
    if recursive and path.is_dir():
        for root, dirs, files in os.walk(path):
            for item in dirs + files:
                os.chmod(os.path.join(root, item), permissions)
    else:
        os.chmod(path, permissions)
    
    # 设置所有权
    if user or group:
        os_change_owner(
            str(path), 
            user or "", 
            group or "", 
            recursive
        )

def run_command(
    command: str, 
    shell_cmd: bool = False, 
    env: dict = None,
    cwd: str = None,
    timeout: int = 300,
    raise_on_error: bool = True
) -> tuple:
    """
    运行系统命令
    
    参数:
        command: 要运行的命令
        shell_cmd: 是否使用shell
        env: 环境变量
        cwd: 工作目录
        timeout: 超时时间 (�?
        raise_on_error: 失败时是否抛出异�?        
    返回:
        (returncode, stdout, stderr)
    """
    if shell_cmd:
        return os_run_os_command(
            command, 
            env=env, 
            cwd=cwd, 
            shell=True,
            timeout=timeout,
            raise_on_error=raise_on_error
        )
    else:
        return run_os_command(
            command, 
            env=env, 
            cwd=cwd, 
            timeout=timeout,
            raise_on_error=raise_on_error
        )

def run_os_command(
    command: str, 
    env: dict = None,
    cwd: str = None,
    timeout: int = 300,
    raise_on_error: bool = True
) -> tuple:
    """
    运行操作系统命令 (不使用shell)
    
    参数:
        command: 要运行的命令 (字符串或列表)
    """
    if isinstance(command, str):
        # 安全地将命令分割为参�?        command = shlex.split(command)
    
    return os_run_os_command(
        command, 
        env=env, 
        cwd=cwd, 
        shell=False,
        timeout=timeout,
        raise_on_error=raise_on_error
    )

def is_root_user() -> bool:
    """
    检查当前用户是否具有root权限
    """
    if OSCheck.is_windows_family():
        import ctypes
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    return os.geteuid() == 0

def get_password(prompt: str = "Enter password: ") -> str:
    """
    安全获取密码输入
    """
    try:
        return gp.getpass(prompt)
    except gp.GetPassWarning:
        # 回退到基本输入（不安全，但作为后备）
        logger.warning("Secure password input failed, using basic input")
        return input(prompt)

@os_aware
def is_unix_service_exist(service_name: str) -> bool:
    """
    检查Unix服务是否存在
    """
    return os_is_service_exist(service_name)

def find_command_in_path(cmd: str) -> str:
    """
    在系统PATH中查找命�?    
    返回:
        str: 命令的完整路�?        
    异常:
        FatalException: 如果命令未找�?    """
    # 尝试直接查找
    path = shutil.which(cmd)
    if path:
        return os.path.abspath(path)
    
    # 扩展PATH搜索
    paths = os.environ.get("PATH", "").split(os.pathsep)
    # 添加标准位置
    standard_paths = [
        "/usr/local/bin", "/usr/bin", "/bin", 
        "/usr/sbin", "/sbin", "/opt/bin"
    ]
    
    # 添加Windows标准路径
    if OSCheck.is_windows_family():
        standard_paths += [
            os.path.join(os.environ.get("SystemRoot", "C:\\Windows"), "System32"),
            os.path.join(os.environ.get("SystemRoot", "C:\\Windows"), "System32\\WindowsPowerShell\\v1.0"),
            os.path.join(os.environ.get("ProgramFiles", "C:\\Program Files"), "Common Files"),
        ]
    
    # 组合所有路�?    search_paths = paths + [p for p in standard_paths if p not in paths]
    
    for path_dir in search_paths:
        cmd_path = os.path.join(path_dir, cmd)
        if OSCheck.is_windows_family() and not cmd_path.endswith('.exe'):
            # 在Windows上尝试不同扩展名
            for ext in os.environ.get('PATHEXT', '.EXE;.COM;.BAT;.CMD').split(';'):
                candidate = cmd_path + ext.lower()
                if os.path.isfile(candidate):
                    return candidate
        else:
            if os.path.isfile(cmd_path):
                return cmd_path
    
    # 尝试PATH解析后查�?    if OSCheck.is_windows_family():
        # 在Windows上使用where命令
        rc, out, _ = os_run_os_command(f"where {cmd}", shell=True)
        if rc == 0 and out.strip():
            return out.splitlines()[0].strip()
    
    raise FatalException(
        errno.ENOENT, 
        f"Command '{cmd}' not found in PATH"
    )

def extract_path_component(path: str, path_fragment: str) -> str:
    """
    从PATH环境变量中提取包含特定片段的组件
    """
    paths = path.split(os.pathsep)
    for component in paths:
        if path_fragment in component:
            return component
    return None

def get_cloud_repo_file() -> str:
    """
    获取cloud仓库文件路径
    """
    if OSCheck.is_windows_family():
        return os.path.join(
            os.environ.get("ProgramData", "C:\\ProgramData"),
            "cloud", "repositories", "cloud.repo"
        )
    
    repo_map = {
        "ubuntu": "/etc/apt/sources.list.d/cloud.list",
        "redhat": "/etc/yum.repos.d/cloud.repo",
        "suse": "/etc/zypp/repos.d/cloud.repo",
        "arch": "/etc/pacman.d/cloud-mirrorlist",
        "alpine": "/etc/apk/repositories.d/cloud.list"
    }
    
    os_family = OSCheck.get_os_family()
    return repo_map.get(os_family, f"/etc/cloud/cloud.repo")

def get_file_owner(file_path: str) -> str:
    """
    获取文件所有�?(Unix系统)
    """
    if OSCheck.is_windows_family():
        # Windows上获取文件所有�?        try:
            import win32security
            sd = win32security.GetFileSecurity(
                file_path, win32security.OWNER_SECURITY_INFORMATION
            )
            owner_sid = sd.GetSecurityDescriptorOwner()
            name, domain, _ = win32security.LookupAccountSid(None, owner_sid)
            return f"{domain}\\{name}"
        except ImportError:
            logger.warning("pywin32 not available, cannot get owner on Windows")
            return "SYSTEM"
    
    try:
        stat_info = os.stat(file_path)
        return pwd.getpwuid(stat_info.st_uid).pw_name
    except KeyError:
        return str(stat_info.st_uid)

class Log4jParser:
    """安全的Log4j配置文件解析�?""
    
    def __init__(self, filename: str):
        self.filename = filename
        self.properties = {}
        self.variables = {}
    
    def _resolve_variables(self, value: str) -> str:
        """解析配置文件中的变量引用"""
        # 支持${var}�?{env:VAR}语法
        var_pattern = re.compile(r'\$\{(env:)?([^\}]+)\}')
        
        def replace_match(match):
            env_prefix, var_name = match.groups()
            if env_prefix:
                # 环境变量
                return os.environ.get(var_name, f"${{{env_prefix}{var_name}}}")
            else:
                # 文件内变�?                return self.properties.get(var_name, match.group(0))
        
        return var_pattern.sub(replace_match, value)
    
    def parse(self) -> dict:
        """解析Log4j配置文件"""
        if not Path(self.filename).is_file():
            logger.error(f"Log4j config file not found: {self.filename}")
            return {}
        
        try:
            with open(self.filename, 'r', encoding='utf-8') as f:
                for line in f:
                    # 跳过注释和空�?                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    
                    # 处理多行�?                    if line.endswith('\\'):
                        line = line[:-1] + f.readline().strip()
                    
                    # 解析键值对
                    if '=' not in line:
                        continue
                    
                    key, value = line.split('=', 1)
                    key = key.strip()
                    value = value.strip()
                    
                    # 存储原始�?                    self.properties[key] = value
            
            # 第二次遍历进行变量解�?            resolved_properties = {}
            for key, raw_value in self.properties.items():
                resolved_properties[key] = self._resolve_variables(raw_value)
            
            return resolved_properties
        
        except Exception as e:
            logger.exception(f"Failed to parse log4j file: {self.filename}")
            raise FatalException(
                errno.EINVAL,
                f"Log4j config parsing error: {str(e)}"
            )

class PackageManagers:
    """包管理器常量"""
    # Windows
    CHOCOLATEY = "chocolatey"
    WINGET = "winget"
    NUGET = "nuget"
    
    # Linux
    APT = "apt"
    YUM = "yum"
    DNF = "dnf"
    ZYPPER = "zypper"
    PACMAN = "pacman"
    APK = "apk"
    
    @staticmethod
    def get_manager() -> str:
        """获取当前系统的包管理�?""
        if OSCheck.is_windows_family():
            # 检查Chocolatey
            choco_path = locate_file("choco.exe") or locate_file("choco")
            if choco_path:
                return PackageManagers.CHOCOLATEY
            
            # 检查Winget
            winget_path = locate_file("winget.exe") or locate_file("winget")
            if winget_path:
                return PackageManagers.WINGET
            
            # 检查NuGet
            nuget_path = locate_file("nuget.exe") or locate_file("nuget")
            if nuget_path:
                return PackageManagers.NUGET
        else:
            distro_family = OSCheck.get_os_family()
            
            if distro_family in ["debian", "ubuntu"]:
                return PackageManagers.APT
            if distro_family in ["redhat", "centos", "amazon"]:
                if locate_file("dnf"):
                    return PackageManagers.DNF
                return PackageManagers.YUM
            if distro_family == "suse":
                return PackageManagers.ZYPPER
            if distro_family == "arch":
                return PackageManagers.PACMAN
            if distro_family == "alpine":
                return PackageManagers.APK
        
        raise FatalException(
            errno.ENOSYS,
            "System package manager not supported"
        )
