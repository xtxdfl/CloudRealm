#!/bin/bash
# Cloud Agent Installation Script
# Version: 1.0.0

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="/opt/cloud-agent"
ETC_DIR="/etc/cloud-agent"
VAR_DIR="/var/lib/cloud-agent"
LOG_DIR="/var/log/cloud-agent"

echo "=== Cloud Agent Installer ==="
echo "Version: 1.0.0"
echo "Install Directory: $INSTALL_DIR"

# Check root
if [ "$EUID" -ne 0 ]; then
    echo "Error: Please run as root"
    exit 1
fi

# Create directories
echo "Creating directories..."
mkdir -p "$INSTALL_DIR/bin"
mkdir -p "$INSTALL_DIR/python"
mkdir -p "$ETC_DIR/conf"
mkdir -p "$ETC_DIR/scripts"
mkdir -p "$VAR_DIR"
mkdir -p "$LOG_DIR"

# Install binary
echo "Installing binary..."
cp -f "$SCRIPT_DIR/cloud-agent" "$INSTALL_DIR/bin/"
chmod 755 "$INSTALL_DIR/bin/cloud-agent"

# Install Python packages
echo "Installing Python packages..."
cp -rf "$SCRIPT_DIR/python/"* "$INSTALL_DIR/python/"
chmod -R 755 "$INSTALL_DIR/python"

# Install config files
echo "Installing config files..."
cp -f "$SCRIPT_DIR/conf/cloud-agent.ini" "$ETC_DIR/conf/"
cp -f "$SCRIPT_DIR/conf/cloud-agent" "$ETC_DIR/conf/"
cp -f "$SCRIPT_DIR/conf/cloud-env.sh" "$ETC_DIR/conf/"
cp -f "$SCRIPT_DIR/conf/logging.conf.sample" "$ETC_DIR/conf/"

chmod 644 "$ETC_DIR/conf/"*

# Install scripts
echo "Installing scripts..."
cp -f "$SCRIPT_DIR/scripts/"* "$ETC_DIR/scripts/"
chmod 755 "$ETC_DIR/scripts/"*

# Install Python dependencies
echo "Installing Python dependencies..."
if command -v python3 &> /dev/null; then
    pip3 install -r "$INSTALL_DIR/python/requirements.txt" 2>/dev/null || true
fi

# Start service (optional)
echo ""
echo "=== Installation Complete ==="
echo ""
echo "To start cloud-agent:"
echo "  $INSTALL_DIR/bin/cloud-agent -server http://your-server:8080 -id your-hostname"
echo ""
echo "Or configure as systemd service:"
echo "  cp /opt/cloud-agent/conf/cloud-agent /etc/init.d/"
echo "  chkconfig --add cloud-agent"
echo ""

exit 0
